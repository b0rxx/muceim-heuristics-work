"""Monta presentation/deck.html: diapositivas originales del artifact (src/slideNN.html) + las nuevas (src/new/).

    python -m presentation.build   # desde learnh-vrp-dyn; necesita results/learnheuristic.csv
"""

import io
import re
from pathlib import Path

import matplotlib
from matplotlib.figure import Figure

from src.utils.plot_bks import bks_gaps

HERE = Path(__file__).parent
SRC = HERE / "src"

ORDER = [
    *(f"slide{i:02d}.html" for i in range(1, 12)),  # portada … resultados del paper
    "new/impl.html",
    "new/assumptions.html",
    "new/v1_v2.html",
    "new/direction.html",
    "new/results_v1.html",
    "new/results_v2.html",
    "new/bks.html",
    "slide12.html",  # fortalezas y preguntas abiertas
    "slide13.html",  # conclusiones
    "slide14.html",  # apéndice
]

# cambios de texto en las diapositivas originales: (archivo, antes, después)
EDITS = [
    ("slide10.html", ">Results</div>", ">Paper Results</div>"),
    ("slide11.html", ">Results by Instance</div>", ">Paper Results by Instance</div>"),
    (
        "slide12.html",
        "<li>Baseline is its own static version</li>",
        "<li>Baseline is its own static version</li><li>Merge direction ignored, yet it changes the cost (our v2: −6%)</li>",
    ),
    (
        "slide13.html",
        ">About 12% cheaper routes and reliable forecasts<",
        ">Paper: ~12% cheaper routes. Ours: 3.5% (v1), 9.2% with v2. Forecasts exact in both<",
    ),
]

CSS = """
@import url(https://fonts.googleapis.com/css2?family=Inter:wght@400;600;700&family=JetBrains+Mono:wght@400;600&display=swap);
@page { size: 1920px 1080px; margin: 0; }
body { margin: 0; background: #1f2937; }
.frame { width: calc(1920px * var(--z, 1)); height: calc(1080px * var(--z, 1)); margin: 0 auto 24px; overflow: hidden; }
.page { width: 1920px; height: 1080px; transform: scale(var(--z, 1)); transform-origin: top left; position: relative; overflow: hidden; }
.page *, .page *::before, .page *::after { box-sizing: border-box; }  /* las originales lo daban por supuesto */
@media print { body { background: none; --z: 1 !important; } .frame { margin: 0; break-after: page; } }
.s { width: 1920px; height: 1080px; box-sizing: border-box; padding: 128px 128px 160px; background: #fafafa;
     display: flex; flex-direction: column; font-family: Inter, Arial, sans-serif; color: #334155; }
.s h2 { font-size: 56px; font-weight: 600; line-height: 1.1; letter-spacing: -1px; color: #0f294a; margin: 0; }
.s .rule { height: 1px; background: #cbd5e1; margin-top: 28px; flex-shrink: 0; }
.s .body { margin-top: 56px; flex: 1; display: flex; flex-direction: column; gap: 40px; min-height: 0; }
.s .body.tight { margin-top: 32px; gap: 16px; }
.s p { font-size: 30px; line-height: 1.4; margin: 0; }
.s b { color: #0f294a; font-weight: 600; }
.s .mono { font-family: "JetBrains Mono", monospace; font-size: 0.9em; white-space: nowrap; }
.s p.mono { font-size: 30px; color: #475569; }
.s .label { font-size: 24px; font-weight: 600; letter-spacing: 2px; line-height: 1.2; color: #64748b; }
.s .note { font-size: 24px; color: #64748b; }
.s .big { font-size: 104px; font-weight: 600; line-height: 1; letter-spacing: -3px; color: #0f294a; }
.s .accent { color: #c84b31 !important; }
.s .strong { font-weight: 600; color: #0f294a; }
.s .cols2, .s .cols3 { display: grid; gap: 64px; }
.s .cols2 { grid-template-columns: 1fr 1fr; }
.s .cols3 { grid-template-columns: 1fr 1fr 1fr; }
.s .col { border-top: 1px solid #cbd5e1; padding-top: 24px; display: flex; flex-direction: column; gap: 16px; }
.s table { border-collapse: collapse; width: 100%; font-size: 26px; }
.s th { text-align: left; font-size: 20px; font-weight: 600; letter-spacing: 2px; color: #64748b; padding: 0 24px 14px 0; }
.s td { padding: 14px 24px 14px 0; border-top: 1px solid #cbd5e1; line-height: 1.3; }
.s td.mono { font-size: 24px; }
.s table.compact { width: auto; margin: 16px 0 12px; }
.s table.compact td, .s table.compact th { padding-right: 96px; }
.s table.compact td { font-size: 44px; }
.s .chart svg { width: 100%; height: auto; display: block; }
.foot { position: absolute; left: 128px; bottom: 64px; font: 24px Inter, Arial, sans-serif; color: #64748b; }
"""

SCRIPT = "<script>const z=()=>document.body.style.setProperty('--z',Math.min(1,(innerWidth-32)/1920));z();addEventListener('resize',z)</script>"


def bks_chart() -> str:
    """Gap de cada enfoque frente al coste real de la BKS, en SVG con la paleta de la presentación."""
    # svg.fonttype none: el navegador pinta el texto con Inter; matplotlib solo mide con DejaVu Sans
    matplotlib.rcParams.update({"svg.fonttype": "none", "font.family": "sans-serif", "font.sans-serif": ["Inter", "DejaVu Sans"], "font.size": 15})
    names, _, _, gaps = bks_gaps()
    series = {"Static (SRC)": ("src", "#94a3b8"), "v1 (DRC)": ("drc", "#0f294a"), "v2 (DRC)": ("drc_v2", "#c84b31")}
    fig = Figure(figsize=(16.64, 5.9))
    ax = fig.subplots()
    width = 0.27
    for k, (label, (column, color)) in enumerate(series.items()):
        ax.bar([i + (k - 1) * width for i in range(len(names))], gaps[column], width, color=color,
               label=f"{label} · mean {gaps[column].mean():+.2f}%")
    ax.axhline(0, color="#334155", lw=1)
    ax.set_xticks(range(len(names)), names, rotation=60, ha="right", fontsize=12, color="#475569")
    ax.set_ylabel("gap vs BKS real cost (%)", color="#475569")
    ax.tick_params(colors="#64748b")
    ax.grid(axis="y", color="#cbd5e1", lw=0.8)
    ax.set_axisbelow(True)
    for side in ("top", "right"):
        ax.spines[side].set_visible(False)
    ax.legend(frameon=False, ncol=3, loc="lower right", bbox_to_anchor=(1, 1))
    fig.patch.set_alpha(0)
    ax.patch.set_alpha(0)
    fig.tight_layout()
    buf = io.StringIO()
    fig.savefig(buf, format="svg")
    return buf.getvalue()[buf.getvalue().index("<svg"):]


def main() -> None:
    sources = {name: (SRC / name).read_text() for name in ORDER}
    for name, old, new in EDITS:
        assert old in sources[name], f"{name}: no encuentro {old!r}"
        sources[name] = sources[name].replace(old, new)
    sources["new/bks.html"] = sources["new/bks.html"].replace("{{BKS_CHART}}", bks_chart())

    pages = []
    for number, name in enumerate(ORDER, start=1):
        html = sources[name]
        if name.startswith("new/"):
            html += f'<div class="foot">{number}</div>'
        else:  # número de página del pie (frame e1) de las originales; la portada no tiene
            html = re.sub(r'(data-frame-id="e1-[^"]*".*?>)\d+(</div>)', rf"\g<1>{number}\g<2>", html, count=1, flags=re.S)
        pages.append(f'<div class="frame"><div class="page">{html}</div></div>')

    deck = (
        '<!DOCTYPE html><html lang="en"><head><meta charset="utf-8">'
        "<title>Learnheuristics for the VRP with Dynamic Inputs</title>"
        f"<style>{CSS}</style></head><body>{''.join(pages)}{SCRIPT}</body></html>"
    )
    (HERE / "deck.html").write_text(deck)
    print(f"{HERE / 'deck.html'}: {len(pages)} diapositivas")


if __name__ == "__main__":
    main()
